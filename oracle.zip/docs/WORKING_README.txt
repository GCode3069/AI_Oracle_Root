╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║                    🩸 WORKING LINCOLN HORROR GENERATOR 🩸                ║
║                                                                           ║
║                         NO API KEYS NEEDED                                ║
║                         GENERATES REAL VIDEOS                             ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝


┌─ INSTANT USAGE ───────────────────────────────────────────────────────────┐
│                                                                           │
│  Generate 1 Video:                                                        │
│    > .\Generate.ps1                                                       │
│                                                                           │
│  Generate 5 Videos:                                                      │
│    > .\Generate.ps1 -Count 5                                              │
│                                                                           │
│  Generate 10 Videos:                                                      │
│    > .\Generate.ps1 -Count 10                                             │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


┌─ WHAT IT DOES ────────────────────────────────────────────────────────────┐
│                                                                           │
│  1. Generates Lincoln horror script from templates (works immediately)   │
│  2. Creates audio with gTTS (free, no API key)                            │
│  3. Creates video with MoviePy (text overlays on dark background)        │
│  4. Exports to output/videos/                                              │
│                                                                           │
│  Result: 1080x1920 MP4 video, 15 seconds, with audio                    │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


┌─ OUTPUT LOCATION ─────────────────────────────────────────────────────────┐
│                                                                           │
│  Videos:  F:\AI_Oracle_Root\scarify\output\videos\                       │
│  Scripts: F:\AI_Oracle_Root\scarify\output\scripts\                      │
│  Audio:   F:\AI_Oracle_Root\scarify\output\audio\                         │
│                                                                           │
│  View:    explorer F:\AI_Oracle_Root\scarify\output\videos                │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


┌─ FIRST RUN (Installs Dependencies) ──────────────────────────────────────┐
│                                                                           │
│  First time will take 30-60 seconds to install:                           │
│    - gTTS (text-to-speech)                                               │
│    - MoviePy (video creation)                                             │
│    - Pillow (image processing)                                            │
│                                                                           │
│  Subsequent runs are instant (30-60s per video)                          │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


┌─ SAMPLE OUTPUT ──────────────────────────────────────────────────────────┐
│                                                                           │
│  Video Name: lincoln_20251027_143022.mp4                                  │
│  Size: ~10-15MB                                                           │
│  Duration: 15 seconds                                                     │
│  Resolution: 1080x1920 (9:16 vertical for Shorts/Reels/TikTok)          │
│  Audio: Lincoln voice (gTTS)                                              │
│  Visual: Dark red background, white headline, red text                     │
│                                                                           │
│  Content: Gruesome Lincoln horror about trending fear topics             │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


┌─ YOUTUBE UPLOAD ──────────────────────────────────────────────────────────┐
│                                                                           │
│  1. Find your videos in output/videos/                                   │
│  2. Upload to YouTube Shorts                                             │
│  3. Add titles like:                                                     │
│     "⚠️ Lincoln Warns: [Headline] | Ghost Horror"                        │
│  4. Add description with Gumroad link                                   │
│  5. Set as Public                                                         │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


┌─ TROUBLESHOOTING ─────────────────────────────────────────────────────────┐
│                                                                           │
│  "Python not found":                                                     │
│    → Install Python 3.8+ from python.org                                 │
│    → Check "Add to PATH" during installation                             │
│                                                                           │
│  "gTTS installation failed":                                             │
│    → Check internet connection (gTTS downloads voices)                     │
│    → Run: pip install gtts                                               │
│                                                                           │
│  "MoviePy installation failed":                                          │
│    → Run: pip install moviepy pillow numpy                               │
│    → May take 30-60 seconds                                              │
│                                                                           │
│  "Video generation fails":                                               │
│    → Check FFmpeg: ffmpeg -version                                       │
│    → Install: winget install ffmpeg                                       │
│                                                                           │
└───────────────────────────────────────────────────────────────────────────┘


╔═══════════════════════════════════════════════════════════════════════════╗
║                                                                           ║
║  💀 THIS GENERATES REAL VIDEOS - NO PLACEHOLDERS                        ║
║                                                                           ║
║  Run: .\Generate.ps1 -Count 1                                            ║
║                                                                           ║
║  Result: Actual MP4 file in output/videos/ within 1 minute              ║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝

