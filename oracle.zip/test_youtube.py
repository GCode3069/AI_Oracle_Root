#!/usr/bin/env python3
import sys
import subprocess

# Use abraham_FIXED.py which already works
subprocess.run([sys.executable, 'abraham_FIXED.py', '1'])






