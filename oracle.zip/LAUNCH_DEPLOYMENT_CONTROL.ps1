# Launch Deployment Control
Write-Host ""
Write-Host "="*70 -ForegroundColor Cyan
Write-Host "  DEPLOYMENT CONTROL - Video Generation System" -ForegroundColor Yellow
Write-Host "="*70 -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting..." -ForegroundColor Green
Write-Host ""

python "DEPLOYMENT_CONTROL.pyw"




